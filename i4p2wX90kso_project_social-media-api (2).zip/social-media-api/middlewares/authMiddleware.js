import jwt from "jsonwebtoken";
import { users } from "../models/userModel.js";
export const protect=(req,res,next)=>{
    const auth=req.headers.authorization;
    if(auth && auth.startsWith('Bearer'))
    {
        try{
            const token=auth.split(' ')[1];
            const decoded=jwt.verify(token,process.env.JWT_SECRET);
            const user=users.find(u=>u.id === decoded.id);
            if (!user) 
                return res.status(401).json({ message: 'User not found' });
            req.user=user;
            next();

        }catch(error){
          return  res.status(401).json({message:'Invalid token'});
        }
        }else{
            res.status(401).json({message:'Not authorised,token missing'});
        }

    };
