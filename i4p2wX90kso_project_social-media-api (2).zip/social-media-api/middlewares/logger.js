export const logger=(req,res,next)=>{
    const skipPaths=['/api/users/register','/api/users/login'];
    if(!skipPaths.includes(req.path)){
console.log(`[${new Date().toISOString()}] ${req.method} ${req.origialUrl}`);
    }
    next();
}