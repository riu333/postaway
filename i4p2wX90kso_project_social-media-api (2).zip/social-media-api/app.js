import express from 'express';
import dotenv from 'dotenv';
import morgan from 'morgan';
import userRoutes from './routes/userRoutes.js';
import postRoutes from './routes/postRoutes.js';
import commentRoutes from './routes/commentRoutes.js';
import likeRoutes from './routes/likeRoutes.js';
import userProfileRoutes from './routes/userProfileRoutes.js';
import { errorHandler } from './middlewares/errorMiddleware.js';
import { logger } from './middlewares/logger.js';

dotenv.config();
const app = express();

const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(logger);
app.use(express.urlencoded({extended:true}));
app.use(morgan('dev'));
app.use('/api/users',userRoutes);
app.use('/api/posts', postRoutes);
app.use('/uploads',express.static('uploads'));
app.use('/api/posts', commentRoutes);
app.use('/api/posts', likeRoutes);
app.use('/api/users', userProfileRoutes);
app.use(errorHandler);




app.get('/', (req, res) => {
    res.send('Social Media API is running...');
  });

  app.listen(PORT, () => {
    console.log(`Server is live at http://localhost:${PORT}`);
  });