import { comments } from '../models/commentModel.js';
import { posts } from '../models/postModel.js';
import { v4 as uuid } from 'uuid';
export const createComment=(req,res)=>{
    const {postId}=req.params;
    const {text}=req.body;
    const post=posts.find(p=>p.id === postId);
    if(!post) 
        return res.status(404).json({message:'post not found'});
    const newComment={id:uuid(),
        userId:req.user.id,postId,text,createdAt:new Date()};
    
    comments.push(newComment);
    res.status(201).json(newComment);
    
};
export const getCommentsByPost=(req,res)=>{
    const {postId}=req.params;
    const post = posts.find(p => p.id === postId);
    if (!post) return res.status(404).json({ message: 'Post not found' });
   const postComments= comments.filter(p=>p.id===postId);
   res.json(postComments);
}