import { users } from "../models/userModel.js";
import { generateToken } from "../utils/generateToken.js";
import {v4 as uuid} from 'uuid';
export const registerUser=(req,res)=>{
    const {name,email,password}=req.body;
   const userexists= users.find(u => u.email===email);
   if (userexists)
    return res.status(400).json({message:'User already exits'});
const newUser={
    id:uuid(),name,email,password};
    users.push(newUser);
    res.status(201).json({id:newUser.id,name:newUser.name,email:newUser.email,token:generateToken(newUser.id)});

};
export const loginUser=(req,res)=>{
    const {email,password}=req.body;
    const user=users.find(u=>u.email===email && u.password===password);
    if (!user)
        return res.status(401).json({message:'Invalid credentials'});
    res.json({id:user.id,name:user.name,email:user.email,token:generateToken(user.id)});
};
export const getProfile=(req,res)=>{
    const user=users.find(u=>u.id===req.user.id);
    if(!user)
        return res.status(404).json({message:'user not found'});
    res.json({id:user.id,name:user.name,email:user.email});
};

