import { posts } from "../models/postModel.js";
import {v4 as uuid} from 'uuid';
export const createPost=(req,res)=>{
    const {content}=req.body;
    const image=req.file?req.file.path:null;
    const newPost={
        id:uuid(),
        userId:req.user.id,
        content,image,createdAt:new Date(),likes:[]
    };
    posts.push(newPost);
    res.status(201).json(newPost);

}
export const getAllPosts = (req, res) => {
  const { caption } = req.query;

  let filteredPosts = posts;

  if (caption) {
    filteredPosts = posts.filter(post =>
      post.content.toLowerCase().includes(search.toLowerCase())
    );
  }

  res.json(filteredPosts);
};

export const getPostById=(req,res)=>{
    const post=posts.find(p=>p.id===req.params.id);
    (!post)
    return res.status(404).json({message:'Post not found'});
    res.json(post);
}  
export const updatePost = (req, res) => {
    const post = posts.find(p => p.id === req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });

    if (post.userId !== req.user.id) {
      return res.status(403).json({ message: 'You can only update your posts' });
    }
    
    post.content = req.body.content || post.content;
    res.json(post);
  };
export const deletePost=(req,res)=>{
    const postIndex=posts.findIndex(p=>p.id===req.params.id);
    if(postIndex==-1)
        return res.status(404).json({message:'post not found'});
    const post = posts[postIndex];
  if (post.userId !== req.user.id) {
    return res.status(403).json({ message: 'You can only delete your posts' });
  }
  
  posts.splice(postIndex,1);
  res.json({message:'post deleted'});

}  ;