import { posts } from "../models/postModel.js";
import { comments } from "../models/commentModel.js";
import { users } from "../models/userModel.js";

//Get all posts by user
export const getPostByUser=(req,res)=>{
    const {userId}=req.params;
    const user = users.find(u=>u.id === userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
const userPosts=posts.filter(p=>p.userId===userId);
res.json(userPosts);

};
// Get all comments by user
export const getCommentsByUser = (req, res) => {
    const { userId } = req.params;
  
    const user = users.find(u => u.id === userId);
    if (!user) return res.status(404).json({ message: 'User not found' });
  
    const userComments = comments.filter(c => c.userId === userId);
    res.json(userComments);
};