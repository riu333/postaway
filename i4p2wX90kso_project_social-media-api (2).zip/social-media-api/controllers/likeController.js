import { posts } from '../models/postModel.js';

// Like a post
export const likePost = (req, res) => {
  const post = posts.find(p => p.id === req.params.postId);
  if (!post) return res.status(404).json({ message: 'Post not found' });

  const userId = req.user.id;
  if (post.likes.includes(userId)) {
    return res.status(400).json({ message: 'You already liked this post' });
  }

  post.likes.push(userId);
  res.json({ message: 'Post liked', likes: post.likes.length });
};

// Unlike a post
export const unlikePost = (req, res) => {
  const post = posts.find(p => p.id === req.params.postId);
  if (!post) return res.status(404).json({ message: 'Post not found' });

  const userId = req.user.id;
  const index = post.likes.indexOf(userId);

  if (index === -1) {
    return res.status(400).json({ message: 'You have not liked this post' });
  }

  post.likes.splice(index, 1);
  res.json({ message: 'Post unliked', likes: post.likes.length });
};
