import express from 'express';
import { getPostByUser, getCommentsByUser } from '../controllers/userProfileController.js';

const router = express.Router();

// Get all posts by a user
router.get('/:userId/posts', getPostByUser);

// Get all comments by a user
router.get('/:userId/comments', getCommentsByUser);

export default router;
