import express from 'express';
import { createComment, getCommentsByPost } from '../controllers/commentController.js';
import { protect } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Get comments on a post (public)
router.get('/:postId/comments', getCommentsByPost);

// Create comment on a post (protected)
router.post('/:postId/comments', protect, createComment);

export default router;
